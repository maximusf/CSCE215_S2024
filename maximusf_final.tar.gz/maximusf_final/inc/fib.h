#ifndef __FIB_H
#define __FIB_H

void printFib(int n);

#endif
